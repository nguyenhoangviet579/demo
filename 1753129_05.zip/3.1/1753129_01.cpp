#define _CRT_SECURE_NO_WARNINGS
#include "header.h"

void main()
{
	List lst;
	init(lst);
	load("input.txt", lst);
	save("output.txt", lst);
	system("pause");
}