#include "Header.h"

void init(List &lst)
{
	lst.head = NULL;
}

void load(const char *path, List &lst)
{
	Node *cur = NULL;
	int x;
	FILE *f = fopen(path, "r");
	if (f == NULL) return;
	fscanf(f, "%d", &x);
	while (x != 0)
	{
		Node *p = new Node;
		p->data = x;
		p->next = NULL;
		if (lst.head == NULL)
		{
			lst.head = p;
			cur = p;
		}
		else
		{
			cur->next = p;
			cur = p;
		}
		fscanf(f, "%d", &x);
	}
	fclose(f);
}

void save(const char *path, List &lst)
{
	FILE *f = fopen(path, "w");
	Node *cur = lst.head;
	while (cur != NULL)
	{
		fprintf(f, "%d ", cur->data);
		cur = cur->next;
	}
	fprintf(f, "0");
	fclose(f);
}

void dell_beg(List &lst)
{
	Node *p = lst.head;
	lst.head = lst.head->next;
	delete p;
}