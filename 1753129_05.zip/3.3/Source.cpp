	#include "header.h"

	void init(List &lst)
	{
		lst.head =  NULL;
	}

	void load(const char *path, List &lst)
	{
		Node *cur = NULL;
		int x;
		FILE *f = fopen(path, "r");
		if (f == NULL) return;
		fscanf(f, "%d", &x);
		while (x != 0)
		{
			Node *p;
			p = new Node;
			p->data = x;
			p->next = NULL;
			if (lst.head == NULL)
			{
				lst.head = p;
				cur = p;
			}
			else
			{
				cur->next = p;
				cur = p;
			}
			fscanf(f, "%d", &x);
		}
		fclose(f);
	}

	void save(const char *path, List &lst)
	{
		FILE *f = fopen(path, "w");
		Node *cur = lst.head;
		while (cur != NULL)
		{
			fprintf(f, "%d ", cur->data);
			cur = cur->next;
		}
		fprintf(f, "0");
		fclose(f);
	}

	Node *GetNode(int x)
	{
		Node *p = new Node;
		if (p == NULL) return NULL;
		p->data = x;
		p->next = NULL;
	}

	void insert(List &lst, Node *a, Node *b)
	{
		for (Node *p = lst.head; p != NULL; p = p->next)
		{
			if (p->data == b->data)
			{
				Node *q = p->next;
				p->next = a;
				a->next = q;
				return;
			}
			if (p->next == NULL)
			{
				p->next = a;
				a->next = NULL;
				return;
			}
		}
	}