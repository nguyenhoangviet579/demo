#define _CRT_SECURE_NO_WARNINGS
#include "header.h"

void main()
{
	

	List lst;
	init(lst);
	load("input.txt", lst);
	int x, y;
	printf("nhap x: ");
	scanf("%d", &x);

	Node *a = GetNode(x);

	printf("nhap y: ");
	scanf("%d", &y);

	Node *b = GetNode(y);
	insert(lst, a, b);
	save("output.txt", lst);

	system("pause");
}