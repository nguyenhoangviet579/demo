#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

struct Node
{
	Node *next;
	int data;
};
struct List
{
	Node *head;
};

void init(List &lst);
void load(const char *path, List &lst);
void save(const char *path, List &lst);
void insert(List &lst, Node *a, Node *b);
Node *GetNode(int x);